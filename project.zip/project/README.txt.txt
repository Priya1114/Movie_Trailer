                                          ---MOVIE TRAILER---
This project is about showing a web page having different movie images and shows their trailer when we click on the images.

#Installation
  -install Python 2.7
  -downloaded fresh_tomatoes file from instructor notes.

#Usage:
 -when entertainment.py is runned ,it displays the web page having movie posters.
 -also a media.py file is created having class Movie in it where functions are defined.
 -media.py is imported in enetertainment.py
 